# Python Color Manager
Want to light up your terminal? Well you didn't come to the right place. This is a very ugly solution, but it works so I don't care really

## Installation
```bash
    pip install pcl
```

## Usage
```bash
    >>> import PCL
    >>> PCL.convertHexToAnsi(0x00a3b2)
    34
```